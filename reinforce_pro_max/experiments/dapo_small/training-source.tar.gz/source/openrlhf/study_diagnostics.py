"""Observational metrics for the controlled study; no RNG or tensor mutation."""
import json
import os
from pathlib import Path
import torch


def emit(kind, record):
    root = os.environ.get("PROMAX_STUDY_METRICS")
    if not root:
        return
    path = Path(root)
    path.mkdir(parents=True, exist_ok=True)
    rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    with (path / f"{kind}.rank{rank}.pid{os.getpid()}.jsonl").open("a") as file:
        file.write(json.dumps(record, allow_nan=False) + "\n")


def normalization_before(experiences):
    if not os.environ.get("PROMAX_STUDY_METRICS"):
        return None
    return [e.advantages.detach().float()[e.action_mask.bool()].clone() for e in experiences]


@torch.no_grad()
def normalization_after(experiences, before, estimator):
    if before is None:
        return
    raw = torch.cat(before)
    after = torch.cat([e.advantages.detach().float()[e.action_mask.bool()] for e in experiences])
    assert raw.shape == after.shape
    active = raw != 0
    emit("normalization", dict(estimator=estimator, active_tokens=raw.numel(),
         raw_nonzero_tokens=int(active.sum()),
         sign_flips=int(((raw.sign() != after.sign()) & active).sum()),
         zero_to_nonzero=int(((raw == 0) & (after != 0)).sum()),
         raw_sum=float(raw.sum()), raw_sum_sq=float(raw.square().sum()),
         normalized_sum=float(after.sum()), normalized_sum_sq=float(after.square().sum())))


@torch.no_grad()
def record_policy(loss, current, old, rollout, advantages, action_mask):
    if not os.environ.get("PROMAX_STUDY_METRICS") or rollout is None:
        return
    mask = action_mask.bool()
    log_ratio = ((current if loss.policy_loss_type == "token_is" else old) - rollout).detach().float()
    positions = action_mask.float().cumsum(-1).clamp_min(1)
    prefix = ((log_ratio * mask).cumsum(-1) / positions).exp()
    token = log_ratio.exp()
    sequence = ((log_ratio * mask).sum(-1) / mask.sum(-1).clamp_min(1)).exp().unsqueeze(-1)
    low, high = loss.vllm_is_truncated_threshold
    token_accept = (token >= low) & (token <= high) & mask
    prefix_accept = (prefix >= low) & (prefix <= high) & mask
    seq_accept = ((sequence >= low) & (sequence <= high)).expand_as(mask) & mask
    previous_valid = torch.zeros_like(mask)
    previous_accept = torch.zeros_like(mask)
    previous_valid[:, 1:] = mask[:, :-1]
    previous_accept[:, 1:] = prefix_accept[:, :-1]
    reentry = prefix_accept & previous_valid & ~previous_accept
    loss._study_calls = getattr(loss, "_study_calls", 0) + 1
    live = token[mask]
    retained = token[prefix_accept]
    applied_gate = loss.vllm_is_correction_type
    if loss.policy_loss_type == "token_is":
        effective_ratio = (current - rollout).detach().float().exp()
        live = effective_ratio[mask]
        applied_gate = "reinforce_pro" if loss.enable_vllm_is_correction else "none"
        retained = effective_ratio[prefix_accept if loss.enable_vllm_is_correction else mask]
    if not torch.isfinite(live).all():
        raise RuntimeError("Nonfinite old/rollout coefficient in study")
    lengths = mask.sum(-1).clamp_min(1)
    current_rollout = (current - rollout).detach().float()
    current_gap = ((current_rollout * mask).sum(-1) / lengths).abs()
    cached_gap = (((old-rollout).detach().float() * mask).sum(-1) / lengths).abs()
    previous_sum = (log_ratio * mask).cumsum(-1) - log_ratio * mask
    lower_reentry = prefix_accept & (previous_sum < (positions - 1) * __import__("math").log(low))
    emit("policy", dict(loss_call=loss._study_calls, gate=applied_gate,
         current_rollout_ppl_gap_sum=float(current_gap.sum()),
         cached_rollout_ppl_gap_sum=float(cached_gap.sum()),
         unfiltered_weight_sum_sq=float(live.square().sum()),
         lower_reentry_weight_sum_sq=float(token[lower_reentry].square().sum()) if loss.enable_vllm_is_correction else 0.,
         active_tokens=int(mask.sum()), responses=mask.shape[0],
         token_rejected=int((mask & ~token_accept).sum()),
         prefix_rejected=int((mask & ~prefix_accept).sum()),
         sequence_rejected=int((mask & ~seq_accept).sum()), prefix_reentries=int(reentry.sum()),
         prefix_token_disagreement=int((prefix_accept != token_accept).sum()),
         prefix_sequence_disagreement=int((prefix_accept != seq_accept).sum()),
         retained_weight_sum=float(retained.sum()), retained_weight_sum_sq=float(retained.square().sum()),
         retained_weight_max=float(retained.max()) if retained.numel() else 0.,
         log_ratio_sum=float(log_ratio[mask].sum()),
         log_ratio_sum_sq=float(log_ratio[mask].square().sum()),
         current_old_max_abs_log_ratio=float((current-old).detach()[mask].abs().max())))
